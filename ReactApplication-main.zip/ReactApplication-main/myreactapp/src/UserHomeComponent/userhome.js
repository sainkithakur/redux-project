import './userhome.css';

function Userhome() {

  return (

    <>
      {/*<!-- About Start -->*/}
      <div class="container-fluid bg-secondary p-0">
        <div class="row g-0">
          <div class="col-lg-12 py-6 px-5">
            <h1 class="display-5 mb-4">Welcome to <span class="text-primary">PMS ,User Panel</span></h1>
          </div>
        </div>
      </div>
      {/*<!-- About End -->*/}
    </>

  );
}

export default Userhome;
