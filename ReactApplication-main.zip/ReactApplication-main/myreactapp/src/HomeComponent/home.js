import './home.css';

function Home() {
  return (

    <>
    {/*<!-- About Start -->*/}
    <div class="container-fluid bg-secondary p-0">
            <div class="row g-0">
                <div class="col-lg-12 py-6 px-5">
                    <h1 class="display-5 mb-4">Welcome To <span class="text-primary">PMS , Home Page</span></h1>
                    <h4 class="text-primary mb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis fugit eveniet laborum architecto delectus. Impedit laboriosam perspiciatis praesentium suscipit velit.</h4>
                    <p class="mb-4">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quaerat, quasi! Omnis voluptatibus aspernatur ratione labore non, excepturi nostrum ipsam dignissimos. Nulla, dolor. Praesentium harum quibusdam ex aliquam reiciendis, dolores eum officiis blanditiis sapiente et nemo beatae itaque architecto iusto cumque aperiam, quam odit ad, cum alias possimus odio inventore quae? Dolorem labore veritatis velit. Harum ea neque eaque aliquam id doloribus sunt accusamus debitis ratione? Totam soluta veniam impedit magni corporis tempora, facere, quam molestiae, sapiente eos vero maiores. Consequuntur tempore et tempora accusantium unde, est repudiandae. Quod cum beatae, non tempora quasi unde, incidunt odio sequi, assumenda dolorum placeat..</p>
                </div>
                
            </div>
        </div>
        {/*<!-- About End -->*/}
    </>

  );
}

export default Home;
